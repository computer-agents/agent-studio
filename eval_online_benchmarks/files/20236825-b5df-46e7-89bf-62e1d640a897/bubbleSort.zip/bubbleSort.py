# Optimized Python program for implementation of Bubble Sort
 
 
def bubbleSort(arr):
    #TODO
    return
   
 
 
# Driver code to test above
if __name__ == "__main__":
    arr = [64, 34, 25, 12, 22, 11, 90]
 
    bubbleSort(arr)
 
    print("Sorted array:")
    for i in range(len(arr)):
        print("%d" % arr[i], end=" ")
 
# This code is modified by Suraj krushna Yadav